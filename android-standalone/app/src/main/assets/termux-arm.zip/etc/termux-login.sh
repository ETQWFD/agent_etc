##
## This script is sourced by /data/data/com.etwqfd.agentetc//bin/login before executing shell.
##
